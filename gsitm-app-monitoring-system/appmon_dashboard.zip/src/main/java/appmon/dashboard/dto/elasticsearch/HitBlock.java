package appmon.dashboard.dto.elasticsearch;

import java.io.Serializable;

public class HitBlock implements Serializable {
    private static final long serialVersionUID = 1;

    private String _shard;
    private String _node;
    private String _index;
    private String _type;
    private String _id;
    private float _score;
    private HitSource _source;

    public String get_shard() {
        return _shard;
    }

    public void set_shard(String _shard) {
        this._shard = _shard;
    }

    public String get_node() {
        return _node;
    }

    public void set_node(String _node) {
        this._node = _node;
    }

    public String get_index() {
        return _index;
    }

    public void set_index(String _index) {
        this._index = _index;
    }

    public String get_type() {
        return _type;
    }

    public void set_type(String _type) {
        this._type = _type;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public float get_score() {
        return _score;
    }

    public void set_score(float _score) {
        this._score = _score;
    }

    public HitSource get_source() {
        return _source;
    }

    public void set_source(HitSource _source) {
        this._source = _source;
    }
}
