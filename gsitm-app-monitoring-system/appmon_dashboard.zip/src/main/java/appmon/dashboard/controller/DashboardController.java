package appmon.dashboard.controller;

import appmon.dashboard.dto.elasticsearch.HitBlock;
import appmon.dashboard.dto.elasticsearch.Result;
import com.google.gson.Gson;
import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.JestResult;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Search;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.util.List;


@Controller
public class DashboardController {

    private static final String VIEW_PATH = "dashboard/";

    @RequestMapping( value = "/dashboard", method = RequestMethod.GET )
    public ModelAndView dashboard(Model model){

        JestClientFactory factory = new JestClientFactory();
        factory.setHttpClientConfig(new HttpClientConfig.Builder("http://220.230.121.6:9200")
                .multiThreaded(true)
                .build());
        JestClient client = factory.getObject();

        //Search search = new Search.Builder("{  \"query\": { \"match_all\": {} } }")
        String gte = "2018-03-23T01:31:00";
        String lt = "2018-03-23T01:33:00";

        String query = "{   \"query\":{      \"range\":{         \"@timestamp\":{            \"gte\":\"" + gte + "\",            \"lt\":\"" + lt+ "\"         }      }   }}";
        System.out.println(query);
        //String query = "{   \"query\":{      \"range\":{         \"@timestamp\":{            \"gte\":\"2018-03-23T01:31:00\",            \"lt\":\"2018-03-23T02:33:00\"         }      }   }}";

        Search search = new Search.Builder(query)
                .addIndex("appmon*")
               .build();

        JestResult response = null;
        try {
            response = client.execute(search);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Result result = new Gson().fromJson(response.getJsonObject(), Result.class);

        List<HitBlock> errBlockList = result.getHits().getHits();

        return new ModelAndView("dashboard/realtime_dashboard", "list", errBlockList);

    }

    @RequestMapping( value = "/dashboard2", method = RequestMethod.GET )
    public String dashboard2(Model model)
    {
        return VIEW_PATH + "dashboard2";
    }

}
