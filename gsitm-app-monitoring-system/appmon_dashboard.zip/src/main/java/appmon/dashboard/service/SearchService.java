package appmon.dashboard.service;

public class SearchService {
}
