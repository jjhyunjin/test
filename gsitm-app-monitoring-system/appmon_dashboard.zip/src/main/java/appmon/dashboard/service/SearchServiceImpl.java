package appmon.dashboard.service;

import appmon.dashboard.dto.elasticsearch.Result;
import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.config.HttpClientConfig;
import org.springframework.stereotype.Service;

@Service
public class SearchServiceImpl {

    public JestClient getSearchData(){

        JestClientFactory factory = new JestClientFactory();
        factory.setHttpClientConfig(new HttpClientConfig.Builder("http://220.230.121.6:9200:9200")
                .multiThreaded(true)
                .build());
        JestClient result = factory.getObject();


        return null;
    }

}
