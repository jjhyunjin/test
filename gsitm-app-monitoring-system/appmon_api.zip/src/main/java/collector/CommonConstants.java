package collector;

public class CommonConstants {
	//  로그 파일 위치
	public final static String LOG_PATH = "/app/appmon/was/appmon_api/logs/appLogs/";
}
