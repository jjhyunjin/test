package collector.service;

import collector.CommonConstants;
import collector.util.DateUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

@Service
public class LogWriteServiceImpl implements LogWriteService {

    @Override
    public void logWrite(Object data) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            String jsonResult = "";
            String fileName = DateUtil.getcurrentDate();
            jsonResult = mapper.writeValueAsString(data);

           PrintWriter pw = new PrintWriter(new FileWriter(CommonConstants.LOG_PATH + fileName + ".txt", true));
            pw.write(jsonResult);
            pw.write("\n");
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
