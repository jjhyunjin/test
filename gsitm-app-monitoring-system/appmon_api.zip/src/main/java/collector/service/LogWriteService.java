package collector.service;

public interface LogWriteService {
    void logWrite(Object data);
}
