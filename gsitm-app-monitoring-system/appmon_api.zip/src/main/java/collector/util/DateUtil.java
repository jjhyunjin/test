package collector.util;

import java.util.Calendar;

public class DateUtil {

	public static String getcurrentDate() {
		Calendar cal = Calendar.getInstance();
		
		int year = cal.get(Calendar.YEAR);
		int month = (cal.get(Calendar.MONTH) + 1);;
		int date = cal.get(Calendar.DATE);
		
		String strDate = Integer.toString(year) +
				((month<10)?"0"+Integer.toString(month):Integer.toString(month)) +
				((date<10)?"0"+Integer.toBinaryString(date):Integer.toString(date));
		return strDate;
		
	}
}
