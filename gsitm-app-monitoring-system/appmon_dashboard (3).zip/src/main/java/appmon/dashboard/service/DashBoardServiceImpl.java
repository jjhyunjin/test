package appmon.dashboard.service;

import appmon.dashboard.dto.elasticsearch.Result;
import com.google.gson.Gson;
import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.JestResult;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Search;
import org.apache.http.HttpHost;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;

@Service
public class DashBoardServiceImpl implements DashBoardService {
/*
    @Override
    public Result getRealtimeTable(String startDate, String endDate) {
        JestClientFactory factory = new JestClientFactory();
        factory.setHttpClientConfig(new HttpClientConfig.Builder("http://220.230.121.6:9200")
                .multiThreaded(true)
                .build());
        JestClient client = factory.getObject();

        //Search search = new Search.Builder("{  \"query\": { \"match_all\": {} } }")
        //String gte = "2018-03-23T01:31:00";
        // String lt = "2018-03-23T01:33:00";

        String gte = String.valueOf(timestampToString(startDate));
        String lt = String.valueOf(timestampToString(endDate));

        String query = "{   \"query\":{      \"range\":{         \"@timestamp\":{            \"gte\":\"" + gte + "\",            \"lt\":\"" + lt+ "\"         }      }   }}";
        // System.out.println(query);
        //String query = "{   \"query\":{      \"range\":{         \"@timestamp\":{            \"gte\":\"2018-03-23T01:31:00\",            \"lt\":\"2018-03-23T02:33:00\"         }      }   }}";

        Search search = new Search.Builder(query)
                .addIndex("appmon*")
                .build();

        JestResult response = null;
        try {
            response = client.execute(search);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Result result = new Gson().fromJson(response.getJsonObject(), Result.class);

        return result;
    }
*/
    @Override
    public Result getRealtimeTable(String startDate, String endDate) {
        try {
            RestHighLevelClient client = new RestHighLevelClient(
                    RestClient.builder(
                            new HttpHost("220.230.121.6", 9200)));

           // String sDate = "2018-03-23T01:31:00";
            // String eDate = "2018-03-24T01:33:00";

            String sDate = String.valueOf(timestampToString(startDate));
            String eDate = String.valueOf(timestampToString(endDate));

            SearchRequest searchRequest = new SearchRequest();
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(QueryBuilders.rangeQuery("@timestamp").to(eDate).from(sDate));
            searchRequest.source(searchSourceBuilder);

            SearchResponse searchResponse = client.search(searchRequest);

            Result result = new Gson().fromJson(searchResponse.toString(), Result.class);

            client.close();
            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }


        return null;
    }

    @Override
    public Result getRealtimeGrape(String startDate, String endDate) {

        try {
            RestHighLevelClient client = new RestHighLevelClient(
                    RestClient.builder(
                            new HttpHost("220.230.121.6", 9200)));

            SearchRequest searchRequest = new SearchRequest();
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(QueryBuilders.rangeQuery("@timestamp").to("2018-03-24T01:33:00").from("2018-03-23T01:31:00"));
           // searchSourceBuilder.aggregation(AggregationBuilders.terms("@timestamp"));
            searchRequest.source(searchSourceBuilder);









            SearchResponse searchResponse = client.search(searchRequest);

            SearchHits hits = searchResponse.getHits();

            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return null;
    }

    public LocalDateTime timestampToString(String date){
        Calendar cal;
        SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");
        try{
            sd.parse(date);
        }catch(ParseException e){
            e.printStackTrace();
        }
        cal = sd.getCalendar();
        //System.out.println("aaa : " + new Timestamp(cal.getTime().getTime()).toLocalDateTime());
        return new Timestamp(cal.getTime().getTime()).toLocalDateTime();
    }
}
