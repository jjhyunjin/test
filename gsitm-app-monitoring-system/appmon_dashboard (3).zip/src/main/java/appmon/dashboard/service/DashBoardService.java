package appmon.dashboard.service;

import appmon.dashboard.dto.elasticsearch.Result;

public interface DashBoardService {
    Result getRealtimeTable(String startDate, String endDate);

    Result getRealtimeGrape(String startDate, String endDate);
}
