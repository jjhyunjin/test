package appmon.dashboard.controller;

import appmon.dashboard.dto.elasticsearch.HitBlock;
import appmon.dashboard.dto.elasticsearch.Result;
import appmon.dashboard.service.DashBoardService;
import com.google.gson.Gson;
import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.JestResult;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Search;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.search.SearchService;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.sql.Timestamp;
import  java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


@Controller
public class DashboardController {

    @Autowired
    protected DashBoardService dashBoardService;

    private static final String VIEW_PATH = "dashboard/";

    @RequestMapping( value = "/dashboard", method = RequestMethod.GET )
    public ModelAndView dashboard(Model model
            ,@RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            ,@RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){
        // 시간을 선택하지 않았을 경우
        if(StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate) ){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Calendar cal = Calendar.getInstance();
            endDate = sdf.format(cal.getTime());
            // 5분전
            cal.add(Calendar.MINUTE, -5);
            startDate = sdf.format(cal.getTime());
        }

       // Result tableResult = dashBoardService.getRealtimeTable(startDate, endDate);
        //List<HitBlock> errBlockList = tableResult.getHits().getHits();

       // Result grapeResult = dashBoardService.getRealtimeGrape(startDate, endDate);



        return new ModelAndView("dashboard/realtime_dashboard", "list", null);

    }


    @RequestMapping( value = "/dashboard/realtime/grape", method = RequestMethod.GET )
    @ResponseBody
    public String realTimeGrape(Model model
            ,@RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            ,@RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){
        // 시간을 선택하지 않았을 경우
        if(StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate) ){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Calendar cal = Calendar.getInstance();
            endDate = sdf.format(cal.getTime());
            // 5분전
            cal.add(Calendar.MINUTE, -5);
            startDate = sdf.format(cal.getTime());
        }

        //Result grapeResult = dashBoardService.getRealtimeGrape(startDate, endDate);

      return dashBoardService.getRealtimeGrape(startDate, endDate).toString();
    }

    @RequestMapping( value = "/dashboard/realtime/table", method = RequestMethod.GET )
    @ResponseBody
    public String realTimeTable(Model model
            ,@RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            ,@RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){
        // 시간을 선택하지 않았을 경우
        if(StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate) ){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Calendar cal = Calendar.getInstance();
            endDate = sdf.format(cal.getTime());
            // 5분전
            cal.add(Calendar.MINUTE, -5);
            startDate = sdf.format(cal.getTime());
        }


        return  dashBoardService.getRealtimeTable(startDate, endDate).toString();
    }



    @RequestMapping( value = "/dashboard2", method = RequestMethod.GET )
    public String dashboard2(Model model)
    {
        return VIEW_PATH + "dashboard2";
    }

}
