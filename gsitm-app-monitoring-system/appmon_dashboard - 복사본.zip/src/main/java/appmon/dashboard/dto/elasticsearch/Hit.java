package appmon.dashboard.dto.elasticsearch;

import java.io.Serializable;
import java.util.List;

public class Hit implements Serializable{
    private static final long serialVersionUID = 1;

    private int total;
    private float max_score;
    private List<HitBlock> hits;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public float getMax_score() {
        return max_score;
    }

    public void setMax_score(float max_score) {
        this.max_score = max_score;
    }

    public List<HitBlock> getHits() {
        return hits;
    }

    public void setHits(List<HitBlock> hits) {
        this.hits = hits;
    }
}
