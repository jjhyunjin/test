package appmon.dashboard.service;

import appmon.dashboard.dto.elasticsearch.Result;
import org.elasticsearch.action.search.SearchResponse;

public interface DashBoardService {
    SearchResponse getRealtimeTable(String startDate, String endDate);

    SearchResponse getRealtimeGrape(String startDate, String endDate);
}
