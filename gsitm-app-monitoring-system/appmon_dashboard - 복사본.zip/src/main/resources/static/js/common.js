/**
 * 모든 페이지 공통 JS
 *
 */
RequestChannelModel = {};
RequestChannelModel.currentDomain=document.domain;


/* pc/mobile 디바이스 체크 */
var osFilter = "win16|win32|win64|mac";
var deviceChecker = null;
if(navigator.platform){
    deviceChecker = (osFilter.indexOf(navigator.platform.toLowerCase())<0 ) ? true : null
}


//Cookie 생성을 위한 Ajax 호출 - 2014.07.31
function fn_ajax_topBannerCall(aUrl){
    jQuery.ajax({
        url : aUrl,
        type : "get",
        timeout : 10000,
        success : function (data){},
        error : function(){}
    });
}

function popup_setCookie() {
    var date = new Date;
    date.setTime(date.getTime() + 1 * 24 * 60 * 60 * 1e3);
    var expires = "; expires=" + date.toGMTString();

    var now = new Date;
    var year = now.getFullYear();
    var month = now.getMonth() + 1;
    if (parseInt(month, 10) < 10) {
        month = "0" + month;
    }
    var date = now.getDate();
    if (parseInt(date, 10) < 10) {
        date = "0" + date;
    }
    value = year + month + date;

    document.cookie = "dimpopup=" + value + expires + "; path=/";
};

function popup_today() {
    popup_setCookie();
    popup_close();
}

function popup_close() {
    if ( jQuery("#footerAppDown").find(".modal_bg70, .modal_bg30").length > 0 ) {
        jQuery("html,body").css({overflow: "initial", position:"initial",width:"initial"});
    }
    jQuery("#footerAppDown").hide();	// 배경없는 팝업일때도 닫혀야 함.
}

function popup_appRun(t) {
    var $t = jQuery(t);
    var media = $t.attr("data-media");
    AppExec.appExecute(location.href, media);
}

function f_refresh_footer(){
    $(".quick_link_area").css({"position":"fixed", "bottom":"0"});
}

var wishStartEvent = false;
//찜 and 트래킹코드 삽입
var comWishButtom = function(loginBeforeProc, successAfterProc){
    $(".icon-zzim").unbind("click.wish").bind("click.wish", function(e){
        if(wishStartEvent == false){
            wishStartEvent = true;
            e.preventDefault();
            e.stopPropagation();
            var $t = $(this);
            var aUrl = $t.hasClass("on") ? "/section/deleteWish" : "/section/createWish";
            var rUrl = decodeURIComponent(gsCommon.appendParam(location.href, {_ : (new Date().getTime())}));

            var prdCd		= $t.attr("data-prdId");
            var dealFlag	= $t.attr("data-dealFlag") != undefined ?$t.attr("data-dealFlag"): "";

            if ( prdCd == "" )
                return ;

            var param = {
                prdCd		: prdCd
                ,returnUrl	: rUrl
                ,dealFlag	: dealFlag
            }

            var sCallBack = function(data){
                var $popup;

                // 로그인 페이지로 이동
                if ( data.success != true ) {
                    if ( data.resultCode === "NEED_LOGIN" ) {
                        if($.isFunction(loginBeforeProc)){
                            loginBeforeProc();
                        }
                        location.href = data.linkUrl;
                    }
                    else{
                        var popup_top = ( $(window).height() / 2  - ( 150 / 2 ) );
                        var popup_left = ( $(window).width() - 280 ) / 2;

                        $popup = $("#zzim_error");
                        $popup.css("height", $(document).height());
                        $popup.find(".zzinm_info_con").css({"top":popup_top+"px","left":popup_left+"px"});
                        $("#zzim_already_text").html(data.resultMessage);
                        $popup.show();
                        $("html").css("overflow","hidden");
                        $(".back_back").css("height", $(document).height());
                    }
                } else {
                    if ( data.resultCode === "DEL_WISH" ) {
                        $popup = $("#zzim_off");
                        $t.removeClass("on");
                    }
                    //data.resultCode === "CRE_WISH"
                    else {
                        $popup = $("#zzim_done");
                        $t.addClass("on");
                    }

                    $popup.fadeIn(10);
                    $(document).bind("touchmove.dim",function(e){e.preventDefault();});
                    setTimeout(function(){
                        $popup.delay(1000).fadeOut(function(){$(document).unbind(".dim");});
                    }, 100);

                    if($.isFunction(successAfterProc)){
                        successAfterProc(prdCd);
                    }
                }

                $(".zzim_off").unbind().click(function(){
                    $popup.hide();
                    $(".back_back").hide();
                    $("html").css({overflow:"",position:"",width:""});
                });
                wishStartEvent = false;
            }

            var eCallBack = function(){
                alert("잠시후 다시 시도해주세요.");
                wishStartEvent = false;
            }

            gsCommon.ajaxCall('get', aUrl, param, sCallBack, eCallBack);
        }
    });
}

var wishBrandStartEvent = false;
//브랜드찜 and 트래킹코드 삽입
var comWishBrandButtom = function(loginBeforeProc, successAfterProc){
        $(".icon-brand-zzim").unbind("click.brand").bind("click.brand", function(e){
            if(wishBrandStartEvent == false){
                wishBrandStartEvent = true;
                e.preventDefault();
                e.stopPropagation();
                var $t = $(this);
                var $brandInfo = $("#wishBrandInfo");
                var aUrl = $t.hasClass("on") ? "/section/myWishBrandDel" : "/section/myWishBrandCreItems";
                var rUrl = decodeURIComponent(gsCommon.appendParam(location.href, {_ : (new Date().getTime())}));

                var brandId		= $brandInfo.attr("data-brandId");
                var brandType	= $brandInfo.attr("data-brandType") != undefined ?$brandInfo.attr("data-brandType"): "";

                if ( brandId == "" || brandType == "")
                    return ;

                var param = {
                    brandType	: brandType
                    ,brandId	: brandId
                    ,returnUrl	: rUrl
                }

                var sCallBack = function(data){
                    var $popup;

                    // 로그인 페이지로 이동
                    if ( data.success != true ) {
                        if ( data.resultCode === "NEED_LOGIN" ) {
                            if($.isFunction(loginBeforeProc)){
                                loginBeforeProc();
                            }
                            location.href = data.linkUrl;
                        }
                        else{
                            var popup_top = ( $(window).height() / 2  - ( 150 / 2 ) );
                            var popup_left = ( $(window).width() - 280 ) / 2;

                            $popup = $("#zzim_error");
                            $popup.css("height", $(document).height());
                            $popup.find(".zzinm_info_con").css({"top":popup_top+"px","left":popup_left+"px"});
                            $("#zzim_already_text").html(data.resultMessage);
                            $popup.show();
                            $("html").css("overflow","hidden");
                            $(".back_back").css("height", $(document).height());
                        }
                    } else {
                        if ( data.resultCode === "DEL_WISH" ) {
                            $popup = $("#brand_zzim_off");
                            $("#brand_zzim_done").hide();
                            $t.removeClass("on");
                            $popup.fadeIn(100).delay(1500).fadeOut(100);
                        }
                        //data.resultCode === "CRE_WISH"
                        else {
                            $popup = $("#brand_zzim_done");
                            $t.addClass("on");
                            $popup.fadeIn(100).delay(3000).fadeOut(100);
                        }

                        if($.isFunction(successAfterProc)){
                            successAfterProc();
                        }
                    }

                    $(".brand_zzim_off").unbind().click(function(){
                        $popup.hide();
                        $(".back_back").hide();
                        $("html").css({overflow:"",position:"",width:""});
                    });
                    wishBrandStartEvent = false;
                }

                var eCallBack = function(){
                    alert("잠시후 다시 시도해주세요.");
                    wishBrandStartEvent = false;
                }

                gsCommon.ajaxCall('get', aUrl, param, sCallBack, eCallBack);
            }
        });

        //레이어 닫기
        $(".btn-zzim-close").click(function(e) {
            $("#brand_zzim_done").hide();
        });
    }


;(function($){
    var gsCommon = function(isDebug){
        var cls = this;
        cls.isDebug = isDebug;

        cls.m_storage = {
            getItem : function(param){
                var rtn = undefined;
                if ( cls.m_storage.enable ) {
                    rtn = window.sessionStorage.getItem( param );
                }
                return rtn;
            },
            setItem : function(name, param){
                if ( cls.m_storage.enable ) {
                    rtn = window.sessionStorage.setItem( name, param );
                }
            },
            removeItem : function(name) {
                if ( cls.m_storage.enable ) {
                    rtn = window.sessionStorage.removeItem(name);
                }
            },
            clear : function(e){
                if ( cls.m_storage.enable ) {
                    window.sessionStorage.clear();
                }
            },
            itemLength : function(e){
                var rtn = 0;
                if ( cls.m_storage.enable ) {
                    rtn = window.sessionStorage.length;
                }
                return rtn;
            },
            getStorageInfo : function(){
                if(cls.isDebug){
                    console.log("");
                    console.log("### storage Info ###");
                    for(var key in window.sessionStorage){
                        var value = $(this.getItem(key)).selector;
                        if(value != 'undefined' && value != ''){
                            console.log(key + " : ", value);
                        }else{
                            console.log(key + " : ", $(this.getItem(key)));
                        }
                    }
                }
            }
        };

        /**
         * 스크롤에 따른 페이징 처리 유무
         */
        cls.checkPaging = function(elList, startEvent){
            var $list;

            if($(elList).size() < 2){
                $list = $(elList).eq(-1);
            }else{
                $list = $(elList).eq(-2);
            }

            if ( 0 < $list.length ) {
                var showH = $list.offset().top;
                if ( showH < cls.scrollHeight()) {
                    if ( $('#moreDiv').css("display") != "none" && startEvent == false ) {
                        return true;
                    }
                }
            }

            return false;
        }

        cls.sendClickTrac = function(JsonData){
            var param = $.param(JsonData);
            var url = "/mobile/commonClickTrac.jsp?"+param;

            return $.ajax({
                url : url
            });
        }

        cls.init = function(){
            if('undefined' == typeof m_storage){
                cls.m_storage.enable = cls.fr_checkStorageEnable();
            }else{
                cls.m_storage.enable = m_storage.enable;
            }

            $(".top_menu_bg,.top_menu_bg02").hide();

            $(".page_top").hide();

            $(".quick_link_area li a").each(function(){
                var tUrl = $(this).attr("href");
                var mseq = "";
                // 홈
                if (tUrl.indexOf("/index.gs") > -1) {
                    mseq = "398042";
                }
                // 카테고리
                else if (tUrl.indexOf("/m/sect/category.gs") > -1) {
                    mseq = "398043";
                }
                // 검색
//				else if (tUrl.indexOf("/m/search/searchNewMain.gs") > -1) {
//					mseq = "398044";
//				}
                // 스마트카트
//				else if (tUrl.indexOf("/mobile/cart/viewCart.gs") > -1) {
//					mseq = "398045";
//				}
                // 주문배송
//				else if (tUrl.indexOf("/mygsshop/myOrderList.gs") > -1) {
//					mseq = "398046";
//				}
                // 마이쇼핑
                else if (tUrl.indexOf("/mygsshop/myshopInfo.gs") > -1) {
                    mseq = "398041";
                }
                // 찜
                else if (tUrl.indexOf("/section/myWishMain.gs") > -1) {
                    mseq = "410808";
                }
                // 최근본상품
                else if (tUrl.indexOf("/section/recntView") > -1) {
                    mseq = "410809";
                }
                if (mseq != "") {
                    tUrl = cls.appendParam(tUrl, {"mseq" : mseq})
                    $(this).attr("href", tUrl);
                }

            });

            $("#footerAppDown").find(".btn_today").attr("href", "javascript:popup_today();");
            $("#footerAppDown").find(".btn_close").attr("href", "javascript:popup_close();");
            $("#footerAppDown").find(".btn_savemoney").attr("href", "javascript:popup_appRun(this);");

            if ( $("#footerAppDown").find(".modal_bg70,.modal_bg30").length > 0 ) {
                $("html,body").css({overflow: "hidden", position:"fixed",width:"100%"});
            }

            if(cls.getCookieValue("appmediatype") == "0"){
                fn_ajax_topBannerCall("/header/top/banner/389490");
            }

            if(document.cookie.indexOf('dimpopup') > 0) {
                popup_close();
            }

            cls.setEvent();
            cls.m_storage.getStorageInfo();
        }

        cls.setEvent = function(){
            // Top Button Bind
            // Top 버튼
            $(window).bind("scroll.page_top", function(){
                if( $(window).scrollTop() > 500 ) {
                    $(".page_top").show();
                } else {
                    $(".page_top").hide();
                }
            });

            $(".page_top").click(function(e){
                window.scrollTo(0, 0);
            });

            $(".quick_link_area .quick_home a, .quick_link_area .quick_category a").click(function(e){
                if(typeof sessionStorage == 'undefined' || sessionStorage == null) {
                    chkRtn = false;
                } else {
                    try {
                        sessionStorage.setItem('gsshop.sesionStorage.enabed', 'Y');
                        sessionStorage.removeItem('gsshop.sesionStorage.enabed');
                        sessionStorage.clear();
                    } catch(e) {
                        chkRtn = false;
                    }
                }
            });

            $(".quick_link_area .quick_lastprd a").click(function(e){
                e.preventDefault();
                var tUrl = $(this).attr("href");
                cls.goLink(tUrl);
            });

            // 앱 알림 수신거부 alert 메세지 표시 - 2015.03.12 이민수 대리 요청. ywjin
            $("#app_footer .footer_sub_menu em").on("click", function(e) {
                e.preventDefault();
                if ("A" == $(this).attr("appGubun")) {
                    alert("알림(PUSH) 설정은 마이쇼핑>설정>설정변경>PUSH 에서 변경할 수 있습니다.");
                } else {
                    alert("알림(PUSH) 설정은 홈>설정>알림>GSSHOP 에서 변경할 수 있습니다.");
                }
            });

            $(".btn_goto_srch").on("click", function(e){
                for(var i=sessionStorage.length-1; i>=0; i--){
                    keyName = sessionStorage.key(i);
                    // 딜플리킹 유지를 위해 딜상품 세션 스토리지는 삭제하지 않는다
                    if( keyName.indexOf('genieSearch') > -1 ){
                        cls.m_storage.removeItem(keyName);
                    }
                }
            });

            $('.footer_cs_tel .footer_link').on('click', function (e) {
                cls.sendClickTrac({ mseq : "415448" });
            });
        }

        cls.fr_checkStorageEnable = function() {
            var chkRtn = true;
            if(typeof sessionStorage == 'undefined' || sessionStorage == null) {
                chkRtn = false;
            } else {
                try {
                    sessionStorage.setItem('gsshop.sesionStorage.enabed', 'Y');
                    sessionStorage.removeItem('gsshop.sesionStorage.enabed');
                } catch(e) {
                    chkRtn = false;
                }
            }
            return chkRtn;
        }

        /**
         * 페이징 처리를 위한 전체갯수 체크
         */
        cls.checkTotalCnt = function( pageIdx, pageSize, totalCnt){
            var itemCnt = pageIdx * pageSize;

            if ( typeof totalCnt == "undefined" ) {
                totalCnt = $(".totCnt").eq(-1).attr("data-value");
            }
            if ( typeof totalCnt == "undefined" ) {
                return true;
            }

            totalCnt = totalCnt.toString().replace(/[^\d]+/g,'');

            if ( itemCnt < parseInt(totalCnt) ) {
                return true;
            } else {
                return false;
            }
        }

        /**
         * url 파싱
         */
        cls.parseUrl = function(url){
            var rtnObj = {};
            var objURL = {};
            var reg = new RegExp("^(.*)[(\?)](.*)", "g");
            var tmpUrl = reg.exec(url);
            if ( tmpUrl !== null ) {
                var url_link = tmpUrl[1];
                var url_param = tmpUrl[2];
                rtnObj["param"] = url_param;
                rtnObj["url"] = url_link;
                url_param.replace(new RegExp("([^?=&]+)(=([^&]*))?", "g"), function ($0, $1, $2, $3) {
                    objURL[$1] = $3;
                });
                rtnObj["params"] = objURL;
            } else {
                rtnObj["param"] = "";
                rtnObj["url"] = url;
                rtnObj["params"] = objURL;
            }

            return rtnObj;
        }

        /**
         * url에 JsonParam 추가
         */
        cls.appendParam = function(url, JsonParam){
            var objUrl = cls.parseUrl(url);

            var orgUrl = objUrl.url;
            var objParam = objUrl.params;

            if('undefined' != typeof JsonParam){
                for(var key in JsonParam){
                    objParam[key] = JsonParam[key];
                }
            }

            var retUrl = [];
            retUrl.push(orgUrl);
            retUrl.push($.param(objParam));

            return retUrl.join('?');
        }

        /**
         * url의 arrParam 파라메터 삭제
         */
        cls.removeParam = function(url, arrParam){
            var objUrl = cls.parseUrl(url);

            var orgUrl = objUrl.url;
            var objParam = objUrl.params;

            if('undefined' != typeof arrParam){
                for(var key in arrParam){
                    if('undefined' != typeof objParam[arrParam[key]]){
                        delete objParam[arrParam[key]];
                    }
                }
            }

            var retUrl = [];
            retUrl.push(orgUrl);
            retUrl.push($.param(objParam));

            return retUrl.join('?');
        }

        /**
         * url에서 key의 값을 리턴
         */
        cls.getParam = function(url, key){
            var objUrl = cls.parseUrl(url);

            return objUrl.params[key];
        }

        /**
         * ajax 처리
         */
        cls.ajaxCall = function(type, url, JsonParam, sCallback, eCallback, bCallback, cCallback){

            if(cls.isDebug){

                console.log("");
                console.log("### gsCommon.ajaxCall ###");
                console.log("URL : ", url);
                if("string" == typeof JsonParam){
                    var jParam = {};
                    JsonParam.replace(new RegExp("([^?=&]+)(=([^&]*))?", "g"), function ($0, $1, $2, $3) {
                        jParam[$1] = $3;
                    });
                    console.log("PARAM : ", jParam);
                }else{
                    console.log("PARAM : ", JsonParam);
                }
            }

            $.ajax({
                type : type,
                url : url,
                data : JsonParam,
                cache : false,
                success: function(data) {
                    if($.isFunction(sCallback)){
                        sCallback(data);
                        cls.ajaxLazyLoad();
                    }

                    cls.m_storage.getStorageInfo();
                },
                beforeSend: function(){
                    if($.isFunction(bCallback)){
                        bCallback();
                    }
                },
                complete: function(){
                    if($.isFunction(cCallback)){
                        cCallback();
                    }
                },
                error: function(data){
                    console.log(data);
                    if($.isFunction(eCallback)){
                        eCallback();
                    }
                }
            });
        }

        /**
         * 동적 from 요청 처리
         */
        cls.formSubmit = function(type, url, JsonParam){
            if(cls.isDebug){
                console.log("");
                console.log("### gsCommon.formSubmit ###");
                console.log("URL : ", url);
                console.log("PARAM : ", JsonParam);
            }

            var $form = $('<form></form>');
            $form.attr('action', url);
            $form.attr('method', type);
            $form.appendTo('body');

            for(var key in JsonParam){
                $form.append("<input type='hidden' value='"+ JsonParam[key] +"' name='"+ key +"'>");
            }

            $form.append("<input type='hidden' value='"+ (new Date().getTime()) +"' name='_'>");

            $form.submit();
        }

        /**
         * 페이지 replace
         */
        cls.pageReplace = function(url, JsonParam){
            location.replace(cls.appendParam(url, JsonParam));
        }

        /**
         * 현재스크롤 위치
         */
        cls.getScrollNowY = function(){
            var de = document.documentElement;
            var b = document.body;
            var now_Y = document.all ? (!de.scrollTop ? b.scrollTop : de.scrollTop) : (window.pageYOffset ? window.pageYOffset : window.scrollY);

            return now_Y;

        }

        /**
         * 화면 높이값
         */
        cls.scrollHeight = function(){
            var de = document.documentElement;
            var b = document.body;
            var scrollHeight = (de.scrollTop == 0 ? b.scrollTop : de.scrollTop) + window.screen.availHeight;

            return scrollHeight;
        }

        /**
         * 케시를 적용한 링크
         */
        cls.goLink = function(url){
            location.href = cls.appendParam(url, { _ : (new Date().getTime()) });
        }

        /**
         * 케시가 적용된 페이지 키정보
         */
        cls.getPageCache = function(){
            var key = cls.getParam(window.location.href, '_');

            if(typeof key != 'undefined' && key != null){
                return key;
            }

            return null;
        }

        /**
         * 스토리지정보
         */
        cls.getStorageOfPageCache = function(key){
            var cacheKey = cls.getPageCache();
            if(cls.m_storage.enable){
                if(cacheKey != null && cls.m_storage.getItem(cacheKey + "." + key) != null){
                    return cls.m_storage.getItem(cacheKey + "." + key);
                }

                return cls.m_storage.getItem(key);
            }

            return null;
        }

        cls.setStorageUsingCache = function(key, value){
            var cacheKey = cls.getPageCache();
            if(cls.m_storage.enable){
                if(cacheKey != null){
                    cls.m_storage.setItem(cacheKey + "." + key, value);
                }else{
                    cls.m_storage.setItem(key, value);
                }
            }
        }

        /**
         * keyGbn이 포함된 스토리지 정보 삭제
         * expGbn은 삭제 제외(array or String)
         */
        cls.removeStorageOfCurrentPage = function(keyGbn, expGbn){
            if(cls.m_storage.enable && typeof keyGbn != 'undefined' && keyGbn != null){
                for(var key in window.sessionStorage){
                    if(key.indexOf(keyGbn) > -1){
                        if(typeof expGbn != 'undefined' && expGbn != null){
                            if(typeof expGbn === 'string'){
                                expGbn = new Array(expGbn);
                            }

                            for(var gbn in expGbn){
                                if(key.indexOf(expGbn[gbn]) > -1){
                                    continue;
                                }
                            }
                        }
                        cls.m_storage.removeItem(key);
                    }
                }
            }
        }

        /**
         * namespace 에 해당되는 모든 이벤트를 삭제
         */
        cls.removeEvent = function(namespace){
            if(typeof namespace != 'undefined' && namespace != null){
                var arrKey = [];
                for(var key in $.cache){
                    if($.cache[key].events){
                        for(var key2 in $.cache[key].events){
                            for(var key3 in $.cache[key].events[key2]){
                                if($.cache[key].events[key2][key3].namespace == namespace){
                                    arrKey.push($($.cache[key].handle.elem));
                                }
                            }
                        }
                    }
                }

                if(arrKey.length > 0){
                    for(var key in arrKey){
                        var $t = arrKey[key];
                        $t.off('.' + namespace);
                    }
                }

                $(window).off('.' + namespace);
            }
        }

        /**
         * # 링크일 경우 Top 으로 이동하는걸 방지
         */
        cls.emptyLink = function(){
            return;
        }

        cls.emptyLinkProc = function(){
            $('a').each(function(){
                if('#' == $(this).attr('href').trim() || '' == $(this).attr('href').trim()){
                    $(this).attr('href','javascript:gsCommon.emptyLink();');
                }
            });
        }

        /**
         * 숫자에 3자리마다 콤마붙이기
         */
        cls.addComma = function(num){
            if(!num || !$.isNumeric(num)){
                return 0;
            }
            return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

        /**
         * 개인정보노출주의 안내문구 popup
         * 1. 해당 문구가 필요한 ui파일에 {>common_noti_toast/} 추가
         * 2. 해당 관련 js파일 onload시에 호출
         */
        cls.notiToastPopup = function(){
            var notiToast = $('.modal_toast');
            $(notiToast).addClass('active').fadeIn(10);
            $(document).bind("touchmove",function(e){
                e.preventDefault();
            });
            setTimeout(function(){
                $(notiToast).addClass('off').fadeOut(function(){
                    $(document).unbind("touchmove");
                });
            }, 2000);
        }

        /**
         * <pre>
         * ajax 처리시 이미지 lazyload 적용
         * </pre>
         */
        cls.ajaxLazyLoad = function(){
            if($.isFunction($.fn.lazyload) && $('.productImg img[data-src]').size() > 0){
                $('.productImg img[data-src]').not('.productImg img[src]').lazyload({
                    effect : "fadeIn"
                });
            }
        }

        /**
         * <pre>
         * 히스토리백처리에 대한 lazyload 적용
         * </pre>
         */
        cls.lazyLoadForHistoryBack = function(){
            if($.isFunction($.fn.lazyload) && $('.productImg img[data-src]').size() > 0){
                $('.productImg img[src*=no_img], .productImg img[src*=base64]').lazyload({
                    effect : "fadeIn"
                });
            }
        }

        cls.getCookieValue = function(c_name) {
            var i, x, y, ARRcookies = document.cookie.split(";");
            for (i = 0; i < ARRcookies.length; i++) {
                x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
                y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
                x = x.replace(/^\s+|\s+$/g, "");
                if (x == c_name) {
                    return unescape(y);
                }
            }
            return "0";
        }

        return cls;
    }

    // 개발시 로그 분석을 위해 파라메터에 true 를 설정하고 운영배포시 false 로 변경한다.
    window.gsCommon = window.gsCommon || new gsCommon(false);

    window.gsCommon.init();
})(jQuery);


(function($){

    // Selector & Combo - 신규 pc mc 통합 버젼 by 이재욱
    $.fn.gsSelect = function(option){
        var option = $.extend({}, $.fn.gsSelect.default, option);
        return this.each(function(){
            var win = $(window);
            var doc = $(document);
            var _this = $(this),
                seleCurrent = _this.find('.'+option.currentClass),
                seleCurrentA = _this.find('a.'+option.currentClass),
                seleOpenner = _this.find('.'+option.openner),
                seleSelect = _this.find('select'),
                seleListBox = _this.find('ul'),
                seleOn = seleListBox.find('.'+option.onClass),
                seleList = seleListBox.find('li'),
                seleA = seleList.find('a'),
                seleLabel = seleList.find('label'),
                seleInput = seleList.find('input'),
                multiCheck = option.multiCheck === true ? true : (_this.hasClass('multi')) ? true : false,
                clicked = option.clicked === true ? true : (_this.hasClass('clicked')) ? true : false,
                currChange = multiCheck === true ? false : option.currChange;
            docH = doc.height();

            // init
            if(currChange == true && multiCheck != true){
                if(seleOn.length == 0 && seleLabel.length > 0) seleList.eq(0).addClass(option.onClass);
                var listText = seleOn.length > 0 ? _this.hasClass('img-type') ? seleOn.html() : seleOn.text() : seleList.eq(0).text();
                var currentReset = seleListBox.length>0 ? listText : seleSelect.find(':selected').text();
                seleCurrent.html(currentReset);
            }

            // input on 체크
            seleInput.is(function(){
                if($(this).parent().hasClass(option.onClass)) $(this).prop('checked', true);
            });
            // 이미지 타입 clicked 설정
            if(_this.hasClass('img-type')) clicked = true;

            function seleFocusIn(){
                _this.addClass(option.focusClass);
            }
            function selefocusOut(){
                _this.removeClass(option.focusClass);
            }
            function overOpt(){
                $(this).parent('li').addClass(option.overClass);
            }
            function outOpt(){
                $(this).parent('li').removeClass(option.overClass);
            }
            // 옵션 열기
            function showOpt(){
                if(!_this.hasClass('disabled')){
                    $('.tmp-select.'+option.onClass).not(_this).removeClass(option.onClass);
                    _this.toggleClass(option.onClass);
                    selefocusOut();
                    var currH = seleCurrent.height();
                    var rePos = Math.floor(_this.offset().top + seleListBox.outerHeight(true)+seleCurrent.height());

                    if(docH < rePos) seleListBox.addClass('up-mode');
                    if(_this.hasClass('img-type')){ // 이미지 타입일때 current 박스 사이즈의 변함에 따라 포지션 조정
                        if(docH < rePos) seleListBox.css({top:'auto',bottom:currH});
                        else seleListBox.css({top:currH});
                    }
                    // List on position

                    var onList = seleListBox.find('li.'+option.onClass);
                    if(onList.length>0){
                        seleListBox.scrollTop(0);
                        var blank = parseInt(seleListBox.css('padding-top').split('px')[0]);
                        var scrollMove = onList.position().top;
                        seleListBox.scrollTop(scrollMove);
                    }
                }
                return false;
            }
            // 옵션 닫기
            function hideOpt(){
                if(multiCheck != true && clicked != true){
                    _this.removeClass(option.onClass);
                }
                _this.removeClass(option.focusClass);
            }
            // 옵션 선택
            function selectOpt(e){
                e.stopPropagation();
                if(option.currChange === true){
                    var OptValue = _this.hasClass('img-type') ? _this.hasClass('only-txt') ? $(this).find('.opt-txt').text() : $(this).html() : seleLabel.length>0 ? $(this).parent().text() : $(this).text();

                    if(!$(this).hasClass(option.disableClass) && !$(this).parent().hasClass(option.disableClass)){
                        if(multiCheck != true) {
                            seleCurrent.html($.trim(OptValue)).removeClass(option.focusClass);
                            seleList.removeClass(option.onClass);
                            $(this).parent().addClass(option.onClass);
                            setTimeout(function(){_this.removeClass(option.onClass)},15);
                        }
                    }else{
                        //alert('해당 옵션은 선택할 수 없습니다!');
                        return false;
                    }
                }
            }
            // 시스템 기본 셀렉터 체인지
            function selectChange(){
                var changeValue = $.trim($(this).find(':selected').text());
                seleCurrent.text(changeValue);
                seleFocusIn();
            }
            // 시스템 기본 셀렉터 이벤트
            seleSelect.unbind().on({
                change : selectChange,
                keyup : selectChange,
                click : function(event){
                    event.stopPropagation();
                    showOpt();
                    selefocusOut();
                },
                focusin : seleFocusIn,
                focusout : selefocusOut,
                mouseenter : function(){seleCurrent.addClass(option.overClass)},
                mouseleave : function(){seleCurrent.removeClass(option.overClass)}
            });
            // 옵션 OnOff
            seleCurrent.unbind().on({'click':showOpt,focusin:seleFocusIn,focusout:selefocusOut});
            seleOpenner.unbind().on({'click':showOpt});
            _this.unbind('.comboAct').on({'mouseleave.comboAct':function(){if(seleSelect.length == 0) hideOpt()}});

            // 키보드 tab
            seleList.last().on('focusout', function(){
                $(this).keydown(function(event){
                    if(event.shiftKey==false && event.keyCode == 9){
                        _this.removeClass(option.onClass);
                    }
                });
            });
            seleCurrentA.on('focusout', function(){
                $(this).keydown(function(event){
                    if(event.shiftKey && event.keyCode == 9){
                        _this.removeClass(option.onClass);
                    }
                });
            });
            // Multi 체크 버블
            seleList.click(function(event){
                if(multiCheck === true || $(this).hasClass(option.disableClass)) event.stopPropagation();
            });
            // Link 셀렉터
            seleA.unbind().on({'click':selectOpt,focusin:overOpt,focusout:outOpt,mouseenter:overOpt,mouseleave:outOpt});
            // Form 셀렉터
            seleInput.unbind().on({change:selectOpt,focusin:seleFocusIn,focusout:selefocusOut});

            seleCurrentA.trigger('focusout');
            seleList.last().trigger('focusout');
            doc.on('click touchmove', function(){
                if(_this.hasClass(option.onClass)) _this.removeClass(option.onClass);
            });
        });
    };
    $.fn.gsSelect.default = {
        openner		: 'btn-opt', // 화살표 토글버튼
        currentClass	: 'current', // 현재값
        onClass		: 'on', // 활성 클래스
        overClass		: 'over',
        focusClass	: 'focus',
        disableClass	: 'disabled', // 비활성 리스트
        currChange	: true, // 선택값 변경
        clicked		: false, // 클릭시 옵션 레이어 유지
        multiCheck	: false // 여러 옵션 선택 (체크박스)
    };

})(jQuery);


// 인풋 숫자 체크 - (20151013)
$.fn.inputNumberCheck = function(type){
    return this.each(function(){
        var _this = $(this);
        _this.keydown(function(event){ // Tip : 파이어폭스의 경우 입력값이 한글일때 키코드가 제대로 들어가지 않음 (해결책 : ime-mode:disabled 셋팅)
            var e = event.which || event.charCode || event.keyCode;
            return (e==8 || e==9 || e==46 || (event.ctrlKey && e==65) || (event.ctrlKey && e==67) || (event.ctrlKey && e==86) || (event.ctrlKey && e==88) || (e>=37 && e<=40) || (e>=48 && e<=57) || (e>=96 && e<= 105));
        });
        // 가격일 경우 3자리 단위(input type="text") 콤마
        if(type === 'price'){
            _this.val(_this.val().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")).on({
                focusin : function(){$(this).val($(this).val().replace(/\,/g, ''))},
                focusout : function(){$(this).val($(this).val().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"))}
            });
        }
    });
};

//iframe -----------------------------------
//바로구매 아이프레임 열기(139미만 앱,웹에서 아이프레임 호출) - 2016.04.26 chohj
var directOrd = (function(){

    var chkInit = false;
    var floatOrderDim;
    var floatOrderLayer;
    var floatOrderFrame;

    var initIframe = function(){

        //footer_index.html - 앱일때는 139이상버젼에서는 네이티브호출하기때문에 템플릿에 넣지않아 html추가해야(구앱)
        if($('#direct-frame-order').length === 0){
            $("footer").after("<div class=\"frame-order-layer\" style=\"bottom:-500px;\"><div id=\"loading_cont\" class=\"loading30\"></div><iframe id=\"direct-frame-order\" src=\"\" width=\"100%\" height=\"380px\" frameborder=\"0\"></iframe></div><div class=\"frame-order-dim\" style=\"display:none;\"></div>");
        }

        floatOrderDim = $('.frame-order-dim');
        floatOrderLayer = $('.frame-order-layer');
        floatOrderFrame = $('#direct-frame-order');

        //아이프레임 로딩시
        floatOrderFrame.on('load', function() {
            $('#loading_cont').hide();
        });

        floatOrderDim.on('touchmove', function(e){
            if (!$(e.target).parents('.noscroll')[0]) {
                e.preventDefault();
            }
        }).on('click', function(e){
            if (floatOrderLayer.is(':visible')) closeIframe();
        });

        chkInit = true;
    };
    var openIframe = function(link){

        if(!chkInit){
            initIframe();
        }else{
            $('#loading_cont').show();
        }

        floatOrderFrame.attr('src', link);

        $('body').addClass('noscroll').bind('mousewheel touchmove', function(e){
            e.preventDefault();
            e.stopPropagation();
        });

        //$('html').css({'overflow':'hidden'});

        floatOrderDim.fadeIn(300);
        floatOrderLayer.show();
        floatOrderLayer.animate({bottom: 0});
    };
    var closeIframe = function(){

        floatOrderLayer.animate({bottom: -380}, function(){
            floatOrderLayer.hide();
            floatOrderFrame.contents().find("body").html("");
        });

        floatOrderDim.fadeOut(300);

        $('body').removeClass('noscroll').unbind('mousewheel touchmove');
        //$('html').css({'overflow':'visible', 'height':''});

        //floatOrderFrame.attr('src', '');
        //floatOrderFrame.attr('src', 'about:blank');
        //floatOrderFrame.removeAttr('src');
    };
    return{
        open: openIframe,
        close: closeIframe
    };
}());
//iframe  -----------------------------------