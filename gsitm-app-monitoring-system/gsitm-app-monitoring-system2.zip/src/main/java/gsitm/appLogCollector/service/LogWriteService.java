package gsitm.appLogCollector.service;

import java.util.HashMap;

public interface LogWriteService {
	public void logWrite(Object data);

}
