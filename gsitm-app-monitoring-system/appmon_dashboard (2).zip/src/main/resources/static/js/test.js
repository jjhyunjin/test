/*
function gd(year, month, day) {
	console.log(new Date(year, month - 1, day).getTime());
    return new Date(year, month - 1, day).getTime();
}
*/

function gd(year, month, day, hours, minutes, seconds) {
   // console.log(new Date(year, month - 1, day, hours, minutes, seconds));
    return new Date(year, month-1, day, hours, minutes, seconds);
}

// Progressbar
if ($(".progress .progress-bar")[0]) {
    $('.progress .progress-bar').progressbar();
}

function init_flot_chart(){

    if( typeof ($.plot) === 'undefined'){ return; }

    console.log('init_flot_chart');
    /*
    var arr_data1 = [
        [gd(2018, 1, 1), 17],
        [gd(2018, 1, 2), 74],
        [gd(2018, 1, 3), 6],
        [gd(2018, 1, 4), 39],
        [gd(2018, 1, 5), 20],
        [gd(2018, 1, 6), 85],
        [gd(2018, 1, 7), 7]
    ];

    var arr_data2 = [
        [gd(2018, 1, 1), 82],
        [gd(2018, 1, 2), 23],
        [gd(2018, 1, 3), 66],
        [gd(2018, 1, 4), 9],
        [gd(2018, 1, 5), 119],
        [gd(2018, 1, 6), 6],
        [gd(2018, 1, 7), 9]
    ];
*/
    var arr_data1 = [
        [gd(2018, 3, 22, 17, 10, 3), 17],
        [gd(2018, 3, 22, 17, 10, 4), 74],
        [gd(2018, 3, 22, 17, 10, 5), 6],
        [gd(2018, 3, 22, 17, 10, 6), 39],
        [gd(2018, 3, 22, 17, 10, 7), 20],
        [gd(2018, 3, 22, 17, 10, 8), 85],
        [gd(2018, 3, 22, 17, 10, 9), 7]
    ];

    var chart_plot_01_settings = {
        series: {
            lines: {
                show: false,
                fill: true
            },
            splines: {
                show: true,
                tension: 0.4,
                lineWidth: 1,
                fill: 0.4
            },
            points: {
                radius: 0,
                show: true
            },
            shadowSize: 2
        },
        grid: {
            verticalLines: true,
            hoverable: true,
            clickable: true,
            tickColor: "#d5d5d5",
            borderWidth: 1,
            color: '#fff'
        },
        colors: ["rgba(38, 185, 154, 0.38)", "rgba(3, 88, 106, 0.38)"],
        xaxis: {
            tickColor: "rgba(51, 51, 51, 0.06)",
            mode: "time",
            //timeformat: "%m-%d %h:%M:%S",


            //tickSize: [1, "hours"],
            //tickLength: 10,
            axisLabel: "Date",
            axisLabelUseCanvas: true,
            axisLabelFontSizePixels: 12,
            axisLabelFontFamily: 'Verdana, Arial',
            axisLabelPadding: 10
        },
        yaxis: {
            ticks: 8,
            tickColor: "rgba(51, 51, 51, 0.06)",
        },
        tooltip: false
    }

    if ($("#chart_plot_01").length){
        console.log('Plot1');

        $.plot( $("#chart_plot_01"), [ arr_data1 ],  chart_plot_01_settings );
    }

}


function init_date_time_picker() {
    console.log('init_date_time_picker');
    $('#datetimepicker6').datetimepicker({
        format : 'YYYY-MM-DD hh:mm:ss'
    });
    $('#datetimepicker7').datetimepicker({
        format : 'YYYY-MM-DD hh:mm:ss'
        ,useCurrent: false //Important! See issue #1075
    });
    $("#datetimepicker6").on("dp.change", function (e) {
        $('#datetimepicker7').data("DateTimePicker").minDate(e.date);
    });
    $("#datetimepicker7").on("dp.change", function (e) {
        $('#datetimepicker6').data("DateTimePicker").maxDate(e.date);
    });

    $( "#btn_grape_realtime" ).click(function() {
        console.log( $('#datetimepicker6').data("DateTimePicker").date());
        console.log( $('#datetimepicker7').data("DateTimePicker").date());

        var start_date = formatDate( $('#datetimepicker6').data("DateTimePicker").date() );
        var end_date =  formatDate( $('#datetimepicker7').data("DateTimePicker").date() );

        console.log( start_date);
        console.log(end_date);


        location.href = "/dashboard?startDate=" + start_date +"&endDate=" + end_date;
       // $.ajax({
       //     url : "",
        //    type : "get"
        //    success : function () {
                
        //    }
       // })
    });

}

function formatDate(date) {
    var d = new Date(date),
        year = d.getFullYear(),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        hour = '' + d.getHours(),
        minute = '' + d.getMinutes(),
        second = '' + d.getSeconds();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    if (hour.length < 2) hour = '0' + hour;
    if (minute.length < 2) minute = '0' + minute;
    if (second.length < 2) second = '0' + second;
    return [year, month, day, hour, minute, second].join('');
}



$(document).ready(function() {
    init_flot_chart();
    init_date_time_picker();
});