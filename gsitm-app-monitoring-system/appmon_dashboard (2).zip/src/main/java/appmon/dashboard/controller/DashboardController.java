package appmon.dashboard.controller;

import appmon.dashboard.dto.elasticsearch.HitBlock;
import appmon.dashboard.dto.elasticsearch.Result;
import com.google.gson.Gson;
import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.JestResult;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Search;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.search.SearchService;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


@Controller
public class DashboardController {

    @Autowired
    protected SearchService searchService;

    private static final String VIEW_PATH = "dashboard/";

    @RequestMapping( value = "/dashboard", method = RequestMethod.GET )
    public ModelAndView dashboard(Model model
            ,@RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            ,@RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){
        // 시간을 선택하지 않았을 경우
        if(StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate) ){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Calendar cal = Calendar.getInstance();
            startDate = sdf.format(cal.getTime());
            // 5분전
            cal.add(Calendar.MINUTE, -5);
            endDate = sdf.format(cal.getTime());
        }

        JestClientFactory factory = new JestClientFactory();
        factory.setHttpClientConfig(new HttpClientConfig.Builder("http://220.230.121.6:9200")
                .multiThreaded(true)
                .build());
        JestClient client = factory.getObject();

        //Search search = new Search.Builder("{  \"query\": { \"match_all\": {} } }")
        //String gte = "2018-03-23T01:31:00";
       // String lt = "2018-03-23T01:33:00";

        String gte = String.valueOf(timestampToString(startDate));
        String lt = String.valueOf(timestampToString(endDate));




        String query = "{   \"query\":{      \"range\":{         \"@timestamp\":{            \"gte\":\"" + gte + "\",            \"lt\":\"" + lt+ "\"         }      }   }}";
       // System.out.println(query);
        //String query = "{   \"query\":{      \"range\":{         \"@timestamp\":{            \"gte\":\"2018-03-23T01:31:00\",            \"lt\":\"2018-03-23T02:33:00\"         }      }   }}";

        Search search = new Search.Builder(query)
                .addIndex("appmon*")
               .build();

        JestResult response = null;
        try {
            response = client.execute(search);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Result result = new Gson().fromJson(response.getJsonObject(), Result.class);

        List<HitBlock> errBlockList = result.getHits().getHits();



        return new ModelAndView("dashboard/realtime_dashboard", "list", errBlockList);

    }

    public LocalDateTime timestampToString(String date){
        Calendar cal;
        SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");
        try{
            sd.parse(date);
        }catch(ParseException e){
            e.printStackTrace();
        }
        cal = sd.getCalendar();
        //System.out.println("aaa : " + new Timestamp(cal.getTime().getTime()).toLocalDateTime());
        return new Timestamp(cal.getTime().getTime()).toLocalDateTime();
    }

    @RequestMapping( value = "/dashboard2", method = RequestMethod.GET )
    public String dashboard2(Model model)
    {
        return VIEW_PATH + "dashboard2";
    }

}
