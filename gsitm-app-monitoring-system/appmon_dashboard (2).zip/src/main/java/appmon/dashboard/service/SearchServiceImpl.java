package appmon.dashboard.service;

import appmon.dashboard.dto.elasticsearch.Result;
import com.google.gson.Gson;
import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.JestResult;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Search;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;

@Service
public class SearchServiceImpl implements SearchService{

    @Override
    public Result getRealtimeTable(String startDate, String endDate) {
        JestClientFactory factory = new JestClientFactory();
        factory.setHttpClientConfig(new HttpClientConfig.Builder("http://220.230.121.6:9200")
                .multiThreaded(true)
                .build());
        JestClient client = factory.getObject();

        //Search search = new Search.Builder("{  \"query\": { \"match_all\": {} } }")
        //String gte = "2018-03-23T01:31:00";
        // String lt = "2018-03-23T01:33:00";

        String gte = String.valueOf(timestampToString(startDate));
        String lt = String.valueOf(timestampToString(endDate));

        String query = "{   \"query\":{      \"range\":{         \"@timestamp\":{            \"gte\":\"" + gte + "\",            \"lt\":\"" + lt+ "\"         }      }   }}";
        // System.out.println(query);
        //String query = "{   \"query\":{      \"range\":{         \"@timestamp\":{            \"gte\":\"2018-03-23T01:31:00\",            \"lt\":\"2018-03-23T02:33:00\"         }      }   }}";

        Search search = new Search.Builder(query)
                .addIndex("appmon*")
                .build();

        JestResult response = null;
        try {
            response = client.execute(search);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Result result = new Gson().fromJson(response.getJsonObject(), Result.class);

        return result;
    }

    public LocalDateTime timestampToString(String date){
        Calendar cal;
        SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");
        try{
            sd.parse(date);
        }catch(ParseException e){
            e.printStackTrace();
        }
        cal = sd.getCalendar();
        //System.out.println("aaa : " + new Timestamp(cal.getTime().getTime()).toLocalDateTime());
        return new Timestamp(cal.getTime().getTime()).toLocalDateTime();
    }
}
