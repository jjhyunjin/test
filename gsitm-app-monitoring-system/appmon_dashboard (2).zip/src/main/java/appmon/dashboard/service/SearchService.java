package appmon.dashboard.service;

import appmon.dashboard.dto.elasticsearch.Result;

public interface SearchService {
    public Result getRealtimeTable(String startDate, String endDate);
}
