package appmon.dashboard.dto.elasticsearch;

import java.io.Serializable;

public class HitSource implements Serializable {
    private static final long serialVersionUID = 1;

    private String os;
    private String appVer;
    private String err;
    private String message;

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getAppVer() {
        return appVer;
    }

    public void setAppVer(String appVer) {
        this.appVer = appVer;
    }

    public String getErr() {
        return err;
    }

    public void setErr(String err) {
        this.err = err;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
